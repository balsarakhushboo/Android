package com.example.employeesystem.model;

import android.content.ContentValues;

public class Employees {

    public static final String TABLE_TABLE = "employees";
    private static final String c_emp_no = "emp_no";
    private static final String c_first_name = "first_name";
    private static final String c_last_name = "last_name";
    private static final String c_gender = "gender";
    private static final String c_hire_date = "hire_date";
    private static final String c_dob = "dob";

    public static final String WHERE = c_emp_no + "=" ;


    public static final String CREATE_EMP_TABLE =
            "create table " + TABLE_TABLE + "("+
                    c_emp_no+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
                    c_first_name + " TEXT,"+
                    c_last_name + " TEXT,"+
                    c_dob + " TEXT,"+
                    c_gender + " TEXT,"+
                    c_hire_date + " TEXT);";



    int emp_no;
    String first_name, last_name, dob, gender, hire_date;

    public Employees() {
    }

    public Employees(String first_name, String last_name, String dob, String gender, String hire_date) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.dob = dob;
        this.gender = gender;
        this.hire_date = hire_date;
    }

    public static ContentValues getEmpContentValues(String fName, String lName, String DOB, String Gender, String hDate)
    {
        ContentValues contentValues = new ContentValues();
        contentValues.put(c_first_name, fName);
        contentValues.put(c_last_name, lName);
        contentValues.put(c_gender, Gender);
        contentValues.put(c_dob, DOB);
        contentValues.put(c_hire_date, hDate);
        return contentValues;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHire_date() {
        return hire_date;
    }

    public void setHire_date(String hire_date) {
        this.hire_date = hire_date;
    }

    public int getEmp_no() {
        return emp_no;
    }

    public void setEmp_no(int emp_no) {
        this.emp_no = emp_no;
    }
}
