package com.example.employeesystem.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.employeesystem.EmployeeActivity;
import com.example.employeesystem.R;
import com.example.employeesystem.model.Employees;


public class EmployeeFragment extends Fragment {


    private EmployeeActivity employeeActivity;
    private EditText etFirstName, etLastName, etDob, etHireDate, etGender, etSalary;
    public Button btnSave;


    public EmployeeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_employee, container, false);
        init(view);
        setOnClickListeners();
        return view;

    }

    private void init(View view) {
        etFirstName = view.findViewById(R.id.etFirstName);
        etLastName = view.findViewById(R.id.etLastName);
        etGender = view.findViewById(R.id.etGender);
        etDob = view.findViewById(R.id.etDOB);
        etHireDate = view.findViewById(R.id.etHireDate);
        etSalary = view.findViewById(R.id.etSalary);
        btnSave = view.findViewById(R.id.btnSave);
    }

    private void setOnClickListeners() {
        btnSave.setOnClickListener(v -> {
            String fn = etFirstName.getText().toString();
            String ln = etLastName.getText().toString();
            String gen = etGender.getText().toString();
            String dob = etDob.getText().toString();
            String hd = etHireDate.getText().toString();
            String sal = etSalary.getText().toString();
            long id = employeeActivity.dbManager.insert(Employees.TABLE_TABLE, Employees.getEmpContentValues(fn, ln, dob, gen, hd));

            if(id != -1)
            {
                Toast.makeText(employeeActivity, "Record Stored", Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(employeeActivity, "Error while adding the record", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onAttach(@NonNull Context context)
    {
        super.onAttach(context);
        employeeActivity = (EmployeeActivity) getActivity();
    }
}