package com.example.employeesystem.utility;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;


public class DBManager
{
    private final Context context;
    private DatabaseHelper databaseHelper;
    private SQLiteDatabase sqLiteDatabase;

    public DBManager(Context context)
    {
        this.context = context;
    }

    public DBManager openDB() throws SQLException
    {
        databaseHelper = new DatabaseHelper(context);
        sqLiteDatabase = databaseHelper.getWritableDatabase();
        //readDatabase will only read and have limitations on queries
        return this;
    }

    public void closeDB()
    {
        databaseHelper.close();
    }

    public long insert(String table, ContentValues values)
    {
        return sqLiteDatabase.insert(table, null, values);
    }

    public Cursor getAll(String table)
    {
        return sqLiteDatabase.rawQuery("select * from "+ table, null);
    }


    //    public long update(String table, ContentValues values, String where)
//    {
//        return sqLiteDatabase.update(table, values, where, null);
//    }
}
