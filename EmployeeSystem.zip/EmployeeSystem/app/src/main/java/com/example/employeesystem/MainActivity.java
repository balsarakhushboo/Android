package com.example.employeesystem;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {

    private TextInputLayout wrpUsername, wrpPassword;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        init();
        onClickListeners();
        onTextChangeListeners(wrpUsername);
        onTextChangeListeners(wrpPassword);

    }

    private void init()
    {
        wrpUsername = findViewById(R.id.wrpUsername);
        wrpPassword = findViewById(R.id.wrpPassword);
        btnLogin = findViewById(R.id.btnLogin);
    }

    private void onClickListeners()
    {
        btnLogin.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String username = wrpUsername.getEditText().getText().toString();
                String password = wrpPassword.getEditText().getText().toString();
                if(username.isEmpty())
                {
                    wrpUsername.setError("Please enter username");
                }
                else if (password.isEmpty())
                {
                    wrpPassword.setError("Please enter password");
                }
                else
                {
                    Intent i = new Intent(MainActivity.this, HomeActivity.class);
                    i.putExtra("username",username);
                    startActivity(i);
                }
            }
        });
    }

    private void onTextChangeListeners(TextInputLayout textInputLayout)
    {
        textInputLayout.getEditText().addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {
                String value = textInputLayout.getEditText().getText().toString();
                if(value.isEmpty())
                {
                    textInputLayout.setError("Please enter valid data");
                }
                else
                {
                    textInputLayout.setError("");
                }
            }

            @Override
            public void afterTextChanged(Editable s)
            {

            }
        });
    }

}